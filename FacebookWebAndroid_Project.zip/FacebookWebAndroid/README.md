# Facebook Web Android project

A minimal Android WebView wrapper that opens Facebook's official website at `https://www.facebook.com/`.

## Features
- App name: Facebook Web
- Custom blue-and-white app icon
- Full-screen WebView with loading progress
- Android back button navigates backward through the website
- Facebook links stay in the app; non-Facebook links open in the system browser
- No custom login form and no code to collect or transmit passwords

## Build an APK

### Option A — Automatic cloud build (no Android Studio needed on your phone)
1. Sign in to GitHub and create a new repository.
2. Upload all files and folders in this project, including the hidden `.github` folder.
3. Open the repository's **Actions** tab.
4. Choose **Build Facebook Web APK** and press **Run workflow** (or wait for the first push build).
5. When it finishes, open the workflow run and download the artifact named `Facebook-Web-debug-APK`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

### Option B — Android Studio
1. Open this folder as an existing project in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is source code, not a precompiled APK; a build environment is needed to compile it.
- Facebook may limit or change features inside WebView. If login does not work in the embedded view, use the official Facebook app or open Facebook in Chrome.
- This project is an independent web wrapper and is not affiliated with or endorsed by Meta.
